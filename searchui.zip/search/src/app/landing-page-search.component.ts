import { Component } from '@angular/core';
import { SearchService } from './search.service';

import { ISearchResult } from './searchresult';

@Component({
    selector: 'landingsearch',
    templateUrl: 'landingsearch-filter.html'
})

export class LandingSearchComponent {
    constructor(private searchService: SearchService){}

    public filterKey = '';
    public filteredItems = [];
    public errorMessage = '';

filter(): void {
    if(this.filterKey!==""){
        this.searchService.searchApplications(this.filterKey)
            .subscribe(data=> this.filteredItems = data,
                       error => this.errorMessage = <any>error);
    }

    else{
        this.filteredItems = [];
    }
}

select(item): void {
    this.filterKey = item;
    this.filteredItems = [];
}
}
