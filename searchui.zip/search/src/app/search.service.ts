import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

import { ISearchResult } from './searchresult';

@Injectable()
export class SearchService {

    constructor(private http: Http) { }


    searchApplications(searchText): Observable<ISearchResult[]> {


  return this.http
                .get('https://www.googleapis.com/customsearch/v1?key=AIzaSyBUy94_QmtaOkwFNz2y6H0vwSlAQhy_sWo&cx=006705822103764354703:klvfg73onog&q=landstar')
                .map((response: Response) => <ISearchResult[]>response.json())
                .do(data => console.log('ALL:' + JSON.stringify(data)))
                .catch(this.handleError);
    }

    private handleError(error: Response) {
        console.error(error);
        return Observable.throw(error.json().error || "Server error");
    }
}
